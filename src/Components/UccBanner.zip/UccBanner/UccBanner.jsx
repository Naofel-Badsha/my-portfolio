const UccBanner = () => {
  return (
    <div className="mx-6 m-auto">
      {/*-----------Heading-----------*/}
      <div className="py-10">
        <h1 className="text-3xl md:text-4xl lg:text-7xl text-center text-black">
          Ucc Banner
        </h1>
        <div className="w-40 h-[2px] bg-deep-orange-600 m-auto mt-2"></div>
      </div>

      {/*---------Slider--------1-----------*/}
      {/* bg-gradient-to-r from-[#c95858] to-[rgba(21, 21, 21)] */}
      <div className="carousel-item relative w-full ">
        <img
          src="https://i.ibb.co/Drs30hD/rev-1.jpg"
          className="w-full h-[400px] object-cover rounded-lg "
        />
        <div className="absolute rounded-lg flex items-center h-full left-0 top-0  
        bg-gradient-to-r from-[#ff004f] e-[rgba(224, 9, 9)]">
          <div className="pl-12">
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl  text-white font-bold">
              My focus is
              </h1>
              <h1 className="text-3xl md:text-4xl lg:text-5xl  text-white font-bold py-3">
              on delivering user-centric
              </h1>
            </div>

            <div className="0">
              <p className="text-xl md:text-2xl lg:text-3xl text-white ">
                Ther are many variable of passages of avilable, But
              </p>
              <p className="text-xl md:text-2xl lg:text-3xl text-white ">
                the majority have suffered alteration in some form
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default UccBanner;
