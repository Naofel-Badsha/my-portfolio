const SuccessStudentCard = ({ successStudent }) => {
  const { image, user_name, review_text } = successStudent;
  return (
    <div className=" bg-[#f1e8e8] border-2  p-6">
      <div className="h-[300px] w-[300px] m-auto ">
        <img src={image} className=" h-[300px] object-cover" />
      </div>

      <div className="p-5">
        <div className="flex items-center justify-start py-4">
          <i className="fas fa-quote-left quote text-4xl text-red-600"></i>
        </div>
        <div className="">
          <h2 className="card-title text-2xl text-red-700">{user_name}</h2>
          <h2 className="card-title text-2xl text-black py-4">Dhaka University</h2>
          <p className="text-xl text-black">{review_text}</p>
        </div>
        <div className="flex items-center justify-end">
          <i className="fa-solid fa-quote-right text-4xl text-red-600"></i>
        </div>
      </div>
    </div>
  );
};

export default SuccessStudentCard;
