import { Link } from "react-router-dom";

const BranceCard = ({ brances }) => {
  const { branch_name, rood_location, phone_number, manager_name } = brances;
  return (
    <div>
      <div className="bg-[#e9d0d0] border-[3px] border-gray-400 rounded-2xl p-8 hover:-translate-y-1 duration-300 ">
        <h2 className="text-3xl text-center text-black font-bold">{branch_name}</h2>
        <div className="">
          <div className="flex gap-4">
            <i className="fa-solid fa-location-dot text-2xl text-red-700 mt-3"></i>
            <h2 className="text-xl text-black py-4">{rood_location}</h2>
          </div>
          <div className="flex gap-4 py-2">
            <i className="fa-solid fa-phone text-2xl text-red-700"></i>
            <p className="text-xl text-black">{phone_number}</p>
          </div>
          <h4 className="text-2xl text-black py-2">
            Meneger:{" "}
            <small className="text-blue-gray-700 text-2xl">
              {manager_name}
            </small>
          </h4>

          <div className="flex items-center justify-center gap-4 py-5">
            <Link>
              <i className="fa-brands fa-facebook-f  flex items-center justify-center w-12 h-12 bg-blue-800 text-white hover:text-gray-700 hover:scale-100 duration-150 text-2xl"></i>
            </Link>
            <Link>
              <i className="fa-brands fa-instagram flex items-center justify-center w-12 h-12 bg-red-300 text-white hover:text-gray-700 hover:scale-100 duration-150 text-2xl"></i>
            </Link>
            <Link>
              <i className="fa-brands fa-youtube flex items-center justify-center w-12 h-12 bg-red-500 text-white hover:text-gray-700 hover:scale-100 duration-150 text-2xl"></i>
            </Link>
            <Link>
              <i className="fa-solid fa-location-dot flex items-center justify-center w-12 h-12 bg-red-500 text-white hover:text-gray-700 hover:scale-100 duration-150 text-2xl"></i>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BranceCard;
