import { useEffect } from "react";
import { useState } from "react";
import BranceCard from "./BranceCard";

const Brance = () => {
  const [brances, setBrances] = useState([]);
  useEffect(() => {
    fetch("brance.json")
      .then((res) => res.json())
      .then((data) => setBrances(data));
  }, []);
  return (
    <div className="mx-6 m-auto">
      {/*-----------Heading-----------*/}
      <div className="mt-16 py-7">
        <h1 className="text-3xl md:text-4xl lg:text-7xl text-center text-black">
          Brance Meneger
        </h1>
        <div className="w-40 h-[2px] bg-deep-orange-600 m-auto mt-2"></div>
      </div>


      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 gr">
        {brances.map((brance) => (
          <BranceCard key={brance.id} brances={brance}></BranceCard>
        ))}
      </div>
    </div>
  );
};

export default Brance;
