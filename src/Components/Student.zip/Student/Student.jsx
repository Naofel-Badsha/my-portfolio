import { useEffect, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/autoplay";
import 'swiper/css/navigation';

// import required modules
import { Autoplay } from "swiper/modules";
// import required modules
import { Navigation } from 'swiper/modules';

import StudentCard from "./StudentCard";

const Student = () => {
    const [students, setStudents] = useState([]);

    useEffect(() => {
      fetch("student.json")
        .then((res) => res.json())
        .then((data) => setStudents(data));
    }, []);

  return (
    <div className="mx-6 m-auto">
      {/*-----------Heading-----------*/}
      <div className="py-10">
        <h1 className="text-3xl md:text-4xl lg:text-7xl text-center text-black">
          Student
        </h1>
        <div className="w-40 h-[2px] bg-deep-orange-600 m-auto mt-2"></div>
      </div>

      <Swiper
    //   Autoplay,
        modules={[Autoplay, Navigation]}
        spaceBetween={25}
        slidesPerView={1}
        autoplay={true}
        grabCursor={true}
        navigation={true}
        delay={"100"}
        loop={true}
        className="mySwiper Navigation"
        breakpoints={{
          640: {
            slidesPerView: 1,
          },
          768: {
            slidesPerView: 2,
          },
          1024: {
            slidesPerView: 3,
          },
          1240: {
            slidesPerView: 4,
          },
        }}
      >
        <div>
          {/*-----------Slider-------1-------*/}
          {students.map((student) => (
            <SwiperSlide>
              <StudentCard
                key={student.id}
                student={student}
              ></StudentCard>
            </SwiperSlide>
          ))}
        </div>
      </Swiper>
    </div>
  );
};

export default Student;
