const StudentCard = ({ student }) => {
  const { image, user_name } = student;
  return (
    <div>
      <div className="shadow-xl border-2">
        <div className="w-[300px] h-[350px] m-auto">
          <img
            src={image}
          className="w-[300px] h-[350px] sm:w-full sm:h-full m-auto p-8 object-cover" />
        </div>
        <div className="px-8 py-8 sm:text-center md:items-center lg:text-start">
          <h2 className=" text-2xl text-red-700 font-bold">{user_name}</h2>
          <p className="text-black py-2 text-2xl font-bold">Section A </p>
          <h4 className="text-red-700 text-xl">Dhaka University</h4>
        </div>
      </div>
    </div>
  );
};

export default StudentCard;
